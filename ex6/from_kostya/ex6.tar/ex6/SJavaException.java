package oop.ex6;

/**
 * The main Exception that encapsulates all Sjava related "accidents".
 * 
 * Created by orrp and guybrush on 6/15/15.
 */
public abstract class SJavaException extends Exception {

    public abstract String getMessage();
}
