package oop.ex6.validator;

/**
 * Created by orrp and guybrush on 6/15/15.
 */
public class IllegalArgumentException extends ScopeException {

    public String getMessage() {
        return "Bad argument provided at method call";
    }
}
