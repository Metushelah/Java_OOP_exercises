
class Customer {
	
	String name;
	String address;
	int balance;
	String log;

	Customer(String customerName, String customerAddress, int customerBalance){
		// Use the arguments of the constructor to initialize the fields
		// of this class.
	}

	int maximumAffordableQuantity(ProductType productType){
		return balance / productType.customerPrice;
	}
	
}
